export const getChapterMindMapPrompt = () => {
  const userPrompt = `\`\`\`ts
export interface NodeObj {
  topic: string
  id: string
  tags?: string[]
  children?: NodeObj[]
}
// 总结父id的第start到end个节点的内容
export interface Summary {
  id: string
  label: string
  /**
   * parent node id of the summary
   */
  parent: string
  /**
   * start index of the summary
   */
  start: number
  /**
   * end index of the summary
   */
  end: number
}
\`\`\`

使用符合  {
  nodeData: NodeObj
  summaries?: Summary[]
} 格式的 JSON 回复用户，这是一个表达**思维导图数据**的递归结构。

**注意！！nodeData、summaries 在同一层级！！**

**严格遵守**：
- 节点 ID 使用递增数字即可
- 注意不要一昧使用兄弟节点关系，适当应用父子级别的分层
- 如果内容为社科类书籍，向节点插入 tags 可选：核心、案例、实践、金句
- Summary 是总结多个同父节点的子节点的工具，会使用花括号把总结文本显示在指定子节点侧边，因为节点存在两侧分布的情况，禁止总结根节点
- 适当添加 Summary，不要添加多余的 Summary
- 最后添加一个金句节点记录几句本章金句
- 适当添加表达该节点内涵的 emoji
- 输出应直接以 { 开始，以 } 结束
`

  return userPrompt
}

export const getMindMapArrowPrompt = () => {
  const userPrompt = `你需要为已有的思维导图添加箭头连接，以显示不同节点之间的关联关系。
\`\`\`ts
export interface NodeObj {
  topic: string
  id: string
  tags?: string[]
  children?: NodeObj[]
}

export interface Arrow {
  id: string
  /**
   * label of arrow
   */
  label: string
  /**
   * id of start node
   */
  from: string
  /**
   * id of end node
   */
  to: string
  /**
   * offset of control point from start point
   */
  delta1: {
    x: number
    y: number
  }
  /**
   * offset of control point from end point
   */
  delta2: {
    x: number
    y: number
  }
  /**
   * whether the arrow is bidirectional
   */
  bidirectional?: boolean
}
\`\`\`

使用符合  {
  arrows?: Arrow[]
} 格式的 JSON 回复用户。


**严格遵守**：
- Arrow 可以添加连接任意节点的箭头，label 间接说明两个节点的联系，delta 的默认值为 50,50。**直接的父子关系不需要链接**
- **直接的父子关系不需要使用 Arrow 链接**
- 只能添加 6 条以下 Arrow，请对最关键的节点关系进行链接
- 确保JSON格式正确，不要返回任何JSON以外的内容
- 输出应直接以 { 开始，以 } 结束
`

  return userPrompt
}

export const getChapterMindMapStreamPrompt = () => {
  const userPrompt = `请为以下章节内容生成思维导图。

**输出格式要求**：
- 使用 mind-elixir 特有格式
- 根节点为一级列表项
- 子节点通过缩进（2个空格）表示层级关系
- 不要在输出中包含 markdown 代码块包裹符号（\`\`\`）
- 直接输出纯文本列表即可

**内容要求**：
- 注意不要一味使用兄弟节点关系，适当应用父子级别的分层
- 适当添加表达该节点内涵的 emoji
- 最后添加一个金句节点记录几句本章金句

**高级功能**：
- 总结（Summary）：使用 \`}:数字 总结文字\` 语法总结前面的节点（例如：\`}:2 前两个节点的总结\`）
- 连线（Arrow）
  - 单向箭头：使用 \`> [^id1] >-箭头标签-> [^id2]\` 语法连接节点（需先用 \`[^id]\` 标记节点）
  - 双向箭头：使用 \`> [^id1] <-箭头标签-> [^id2]\` 语法连接节点（需先用 \`[^id]\` 标记节点）

**输出示例**：
\`\`\`
- 📚 第一章：主题
  - 💡 核心观点1 [^id1]
    - 详细说明1-1
    - 详细说明1-2
    - }:2 以上两点说明了...
  - 💡 核心观点2 [^id2]
    - 案例2-1
    - 案例2-2
    - > [^id1] <-互相支撑-> [^id2]
  - ✨ 金句
    - "这是一句金句"
    - "这是另一句金句"
\`\`\`

请直接输出纯文本列表，不要有任何其他格式包裹。
`

  return userPrompt
}
