export default ['packages/*'];
